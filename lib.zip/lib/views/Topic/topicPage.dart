import 'package:flutter/material.dart';

class TopicPage extends StatefulWidget {
  TopicPage({Key? key}) : super(key: key);

  @override
  _TopicPageState createState() => _TopicPageState();
}

class _TopicPageState extends State<TopicPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
       child: null,
    );
  }
}